I will be making sequels to this tutorial that build upon what we've made. If you want to be notified when they come out, there will be a form to enter your email at the bottom of the webpage. 

The tile set is from the Retro Lines platformer asset pack.
https://v3x3d.itch.io/retro-lines

The font is from fontmeme.com. The font did not come with a license file, but the download page said it was free for personal use.

Thanks for reading!

-Diego (CodingKaiju.com)